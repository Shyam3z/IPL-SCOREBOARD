function goToNextPage() {
    window.location.href = 'scorecard.html';
}

function goToNextPage1() {
    window.location.href = 'tables.html';
}
function goToNextPage2() {
    window.location.href = 'schedules.html';
}
function goToNextPage3() {
    window.location.href = "https://www.iplt20.com/photos";
}
function goTonextPage7() {

    window.location.href = "https://www.gamepix.com/t/cricket-games";

}
