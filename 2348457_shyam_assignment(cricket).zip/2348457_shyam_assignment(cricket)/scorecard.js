let playerName = '';
let score = 0;
let runs = 0;
let wickets = 0;
let overs = 0;
let balls = 0;
let runsPerBall = [];
let totalOvers;

function startGame() {
    playerName = document.getElementById('playerName').value;
    if (playerName.trim() === '') {
        alert('Please enter a valid player name.');
        return;
    }

    document.getElementById('playerInfo').innerText = 'Player: ' + playerName;
    document.getElementById('gameArea').style.display = 'block';
}

function hit() {
    const randomScore = Math.floor(Math.random() * 7); 
    updateScore(randomScore);
}

function updateScore(run) {
    score += run;
    document.getElementById('score').innerText = 'Score: ' + score;

    if (score >= 50) {
        alert('Game Over! ' + playerName + '\'s final score is ' + score);
        resetGame();
    }
}

function resetGame() {
    playerName = '';
    score = 0;
    document.getElementById('playerInfo').innerText = '';
    document.getElementById('score').innerText = 'Score: ' + score;
    document.getElementById('playerName').value = '';
    document.getElementById('gameArea').style.display = 'none';
}

function startMatch() {
    totalOvers = parseInt(document.getElementById('oversInput').value);
    resetScore();
    updateDisplay();
}

function updateWicket() {
    wickets++;
    balls++;
    runsPerBall.push('W');

    if (balls === 6) {
        updateDisplay();
        setTimeout(endOver, 0);
    }

    if (wickets >= 10) {
        document.getElementById('message').innerText = 'All out! Innings Over!';
        resetScore();
    }

    updateDisplay();
}

function updateWide() {
    runs += 1;
    runsPerBall.push('WD');

    updateDisplay();
}

function updateNoBall() {
    runs += 1;
    runsPerBall.push('NB');

    updateDisplay();
}

function endOver() {
    balls = 0;
    overs++;
    runsPerBall = [];
}

function updateDisplay() {
    document.getElementById('runs').innerText = runs;
    document.getElementById('wickets').innerText = wickets;

    if (balls === 6) {
        document.getElementById('overs').innerText = overs + 1 + '.0';
    } else {
        document.getElementById('overs').innerText = overs + '.' + balls;
    }

    document.getElementById('runsPerBall').innerText = runsPerBall.join(' ');
}

function resetScore() {
    runs = 0;
    wickets = 0;
    overs = 0;
    balls = 0;
    runsPerBall = [];
    document.getElementById('message').innerText = '';
    updateDisplay();
}

